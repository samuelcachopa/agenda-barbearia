import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { startOfMonth, endOfMonth } from 'date-fns';

export interface DashboardStats {
  monthlyRevenue: number;
  completedAppointments: number;
  noShows: number;
  pendingPayments: number;
  totalClients: number;
  upcomingAppointments: number;
}

export function useDashboardStats() {
  const { user } = useAuth();
  const now = new Date();
  const monthStart = startOfMonth(now);
  const monthEnd = endOfMonth(now);

  return useQuery({
    queryKey: ['dashboard-stats', user?.id, monthStart.toISOString()],
    queryFn: async (): Promise<DashboardStats> => {
      // Fetch payments for this month
      const { data: payments } = await supabase
        .from('payments')
        .select('amount, status')
        .gte('created_at', monthStart.toISOString())
        .lte('created_at', monthEnd.toISOString());

      // Fetch appointments for this month
      const { data: appointments } = await supabase
        .from('appointments')
        .select('status, scheduled_at')
        .gte('scheduled_at', monthStart.toISOString())
        .lte('scheduled_at', monthEnd.toISOString());

      // Fetch total clients
      const { count: totalClients } = await supabase
        .from('clients')
        .select('id', { count: 'exact', head: true });

      // Fetch upcoming appointments
      const { count: upcomingAppointments } = await supabase
        .from('appointments')
        .select('id', { count: 'exact', head: true })
        .gte('scheduled_at', now.toISOString())
        .in('status', ['scheduled', 'confirmed']);

      const monthlyRevenue = payments?.filter(p => p.status === 'paid')
        .reduce((sum, p) => sum + Number(p.amount), 0) || 0;

      const completedAppointments = appointments?.filter(a => a.status === 'completed').length || 0;
      const noShows = appointments?.filter(a => a.status === 'no_show').length || 0;
      const pendingPayments = payments?.filter(p => p.status === 'pending').length || 0;

      return {
        monthlyRevenue,
        completedAppointments,
        noShows,
        pendingPayments,
        totalClients: totalClients || 0,
        upcomingAppointments: upcomingAppointments || 0,
      };
    },
    enabled: !!user,
  });
}
