import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface Payment {
  id: string;
  appointment_id: string | null;
  client_id: string;
  amount: number;
  payment_method: 'pix' | 'credit_card' | 'debit_card' | 'cash' | 'other' | null;
  status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_link: string | null;
  paid_at: string | null;
  created_at: string;
  clients: {
    id: string;
    name: string;
  };
}

export interface CreatePaymentData {
  appointment_id?: string;
  client_id: string;
  amount: number;
  payment_method?: string;
}

export function usePayments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: payments = [], isLoading } = useQuery({
    queryKey: ['payments', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('payments')
        .select(`
          *,
          clients (id, name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Payment[];
    },
    enabled: !!user,
  });

  const createPayment = useMutation({
    mutationFn: async (data: CreatePaymentData) => {
      // Generate simulated payment link
      const paymentLink = `https://pagamento.agendapro.com/${crypto.randomUUID()}`;
      
      const { data: newPayment, error } = await supabase
        .from('payments')
        .insert([{ ...data, user_id: user?.id, payment_link: paymentLink }])
        .select()
        .single();

      if (error) throw error;
      return newPayment;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      toast({ title: 'Link de pagamento gerado!' });
    },
    onError: (error: Error) => {
      toast({ variant: 'destructive', title: 'Erro ao gerar pagamento', description: error.message });
    },
  });

  const updatePaymentStatus = useMutation({
    mutationFn: async ({ id, status, payment_method }: { id: string; status: string; payment_method?: string }) => {
      const updateData: Record<string, unknown> = { status };
      if (status === 'paid') {
        updateData.paid_at = new Date().toISOString();
      }
      if (payment_method) {
        updateData.payment_method = payment_method;
      }

      const { error } = await supabase
        .from('payments')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      toast({ title: 'Pagamento atualizado!' });
    },
    onError: (error: Error) => {
      toast({ variant: 'destructive', title: 'Erro ao atualizar pagamento', description: error.message });
    },
  });

  return { payments, isLoading, createPayment, updatePaymentStatus };
}
