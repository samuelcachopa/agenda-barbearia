import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Calendar, CheckCircle, CreditCard, MessageCircle, ArrowRight, Loader2 } from 'lucide-react';

export default function Index() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const features = [
    {
      icon: Calendar,
      title: 'Agenda Inteligente',
      description: 'Visualize sua semana completa e gerencie todos os seus horários em um só lugar.',
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Automático',
      description: 'Envio automático de confirmações e lembretes 24h antes do atendimento.',
    },
    {
      icon: CreditCard,
      title: 'Cobranças Simplificadas',
      description: 'Gere links de pagamento via Pix e cartão de forma instantânea.',
    },
    {
      icon: CheckCircle,
      title: 'Dashboard Completo',
      description: 'Acompanhe seu faturamento, faltas e atendimentos em tempo real.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="container mx-auto px-4 py-20 lg:py-32 relative">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Calendar className="w-4 h-4" />
              Gestão de agenda profissional
            </div>
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Simplifique sua agenda,{' '}
              <span className="text-primary">maximize seus ganhos</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              A solução completa para prestadores de serviço: agendamentos,
              lembretes automáticos e cobranças integradas em um só lugar.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="btn-gradient-primary text-lg h-14 px-8"
                onClick={() => navigate('/auth')}
              >
                Começar gratuitamente
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg h-14 px-8"
                onClick={() => navigate('/auth')}
              >
                Fazer login
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Tudo que você precisa
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Desenvolvido especialmente para barbeiros, personal trainers,
              esteticistas e outros profissionais de serviços.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="bg-card rounded-xl p-6 shadow-md border border-border/50 hover:shadow-lg transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-12 shadow-xl">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
              Pronto para organizar sua agenda?
            </h2>
            <p className="text-lg text-primary-foreground/80 mb-8">
              Comece agora e veja a diferença na gestão do seu negócio.
            </p>
            <Button
              size="lg"
              variant="secondary"
              className="text-lg h-14 px-8 bg-card text-foreground hover:bg-card/90"
              onClick={() => navigate('/auth')}
            >
              Criar conta gratuita
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2025 AgendaPro. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
