import { useState } from 'react';
import { usePayments, CreatePaymentData } from '@/hooks/usePayments';
import { useClients } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  CreditCard, 
  Copy, 
  Check, 
  ExternalLink,
  QrCode,
  Banknote
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function Pagamentos() {
  const { payments, isLoading, createPayment, updatePaymentStatus } = usePayments();
  const { clients } = useClients();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [selectedClientId, setSelectedClientId] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('pix');

  const handleCreatePayment = async () => {
    if (!selectedClientId || !amount) {
      toast({ variant: 'destructive', title: 'Preencha todos os campos' });
      return;
    }

    const data: CreatePaymentData = {
      client_id: selectedClientId,
      amount: parseFloat(amount.replace(',', '.')),
      payment_method: paymentMethod,
    };

    await createPayment.mutateAsync(data);
    setIsDialogOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setSelectedClientId('');
    setAmount('');
    setPaymentMethod('pix');
  };

  const handleCopyLink = async (link: string, id: string) => {
    await navigator.clipboard.writeText(link);
    setCopiedId(id);
    toast({ title: 'Link copiado!' });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleMarkAsPaid = async (id: string, method: string) => {
    await updatePaymentStatus.mutateAsync({ id, status: 'paid', payment_method: method });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-warning/20 text-warning border-warning/30',
      paid: 'bg-success/20 text-success border-success/30',
      failed: 'bg-destructive/20 text-destructive border-destructive/30',
      refunded: 'bg-muted text-muted-foreground border-border',
    };

    const labels: Record<string, string> = {
      pending: 'Pendente',
      paid: 'Pago',
      failed: 'Falhou',
      refunded: 'Reembolsado',
    };

    return (
      <Badge variant="outline" className={cn('font-medium', styles[status])}>
        {labels[status]}
      </Badge>
    );
  };

  const getMethodIcon = (method: string | null) => {
    switch (method) {
      case 'pix':
        return <QrCode className="w-4 h-4" />;
      case 'credit_card':
      case 'debit_card':
        return <CreditCard className="w-4 h-4" />;
      case 'cash':
        return <Banknote className="w-4 h-4" />;
      default:
        return <CreditCard className="w-4 h-4" />;
    }
  };

  const pendingTotal = payments
    .filter((p) => p.status === 'pending')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const paidTotal = payments
    .filter((p) => p.status === 'paid')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Pagamentos</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie cobranças e pagamentos
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-gradient-primary">
              <Plus className="w-4 h-4 mr-2" />
              Gerar cobrança
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Nova Cobrança</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Cliente</Label>
                <Select value={selectedClientId} onValueChange={setSelectedClientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Valor (R$)</Label>
                <Input
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="100.00"
                />
              </div>
              <div className="space-y-2">
                <Label>Método de pagamento</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pix">
                      <span className="flex items-center gap-2">
                        <QrCode className="w-4 h-4" />
                        Pix
                      </span>
                    </SelectItem>
                    <SelectItem value="credit_card">
                      <span className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4" />
                        Cartão de crédito
                      </span>
                    </SelectItem>
                    <SelectItem value="debit_card">
                      <span className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4" />
                        Cartão de débito
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50 text-sm text-muted-foreground">
                <p className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-primary" />
                  Um link de pagamento será gerado automaticamente
                </p>
              </div>
              <Button
                onClick={handleCreatePayment}
                className="w-full btn-gradient-primary"
                disabled={createPayment.isPending}
              >
                Gerar link de pagamento
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="stat-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pagamentos pendentes</p>
                <p className="text-2xl font-bold text-warning mt-2">
                  {formatCurrency(pendingTotal)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="stat-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total recebido</p>
                <p className="text-2xl font-bold text-success mt-2">
                  {formatCurrency(paidTotal)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <Check className="w-6 h-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-primary" />
            Histórico de Pagamentos
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : payments.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <CreditCard className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum pagamento registrado ainda</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Método</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">
                        {payment.clients.name}
                      </TableCell>
                      <TableCell className="font-semibold">
                        {formatCurrency(Number(payment.amount))}
                      </TableCell>
                      <TableCell>
                        <span className="flex items-center gap-2">
                          {getMethodIcon(payment.payment_method)}
                          {payment.payment_method === 'pix' && 'Pix'}
                          {payment.payment_method === 'credit_card' && 'Crédito'}
                          {payment.payment_method === 'debit_card' && 'Débito'}
                          {payment.payment_method === 'cash' && 'Dinheiro'}
                          {!payment.payment_method && '-'}
                        </span>
                      </TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(payment.created_at), "dd/MM/yyyy HH:mm", {
                          locale: ptBR,
                        })}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {payment.payment_link && payment.status === 'pending' && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  handleCopyLink(payment.payment_link!, payment.id)
                                }
                              >
                                {copiedId === payment.id ? (
                                  <Check className="w-4 h-4" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  window.open(payment.payment_link!, '_blank')
                                }
                              >
                                <ExternalLink className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                          {payment.status === 'pending' && (
                            <Button
                              size="sm"
                              className="bg-success hover:bg-success/90 text-success-foreground"
                              onClick={() =>
                                handleMarkAsPaid(payment.id, payment.payment_method || 'other')
                              }
                            >
                              Marcar pago
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
