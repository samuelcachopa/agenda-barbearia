import { useDashboardStats } from '@/hooks/useDashboardStats';
import { useAppointments } from '@/hooks/useAppointments';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  DollarSign, 
  CalendarCheck, 
  UserX, 
  Clock, 
  Users,
  TrendingUp
} from 'lucide-react';
import { format, addDays, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const today = new Date();
  const { appointments: todayAppointments, isLoading: appointmentsLoading } = useAppointments(
    startOfDay(today),
    endOfDay(today)
  );

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const statCards = [
    {
      title: 'Faturamento do mês',
      value: stats ? formatCurrency(stats.monthlyRevenue) : '-',
      icon: DollarSign,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
    {
      title: 'Atendimentos realizados',
      value: stats?.completedAppointments ?? '-',
      icon: CalendarCheck,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: 'Faltas',
      value: stats?.noShows ?? '-',
      icon: UserX,
      color: 'text-destructive',
      bgColor: 'bg-destructive/10',
    },
    {
      title: 'Pagamentos pendentes',
      value: stats?.pendingPayments ?? '-',
      icon: Clock,
      color: 'text-warning',
      bgColor: 'bg-warning/10',
    },
    {
      title: 'Total de clientes',
      value: stats?.totalClients ?? '-',
      icon: Users,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: 'Próximos agendamentos',
      value: stats?.upcomingAppointments ?? '-',
      icon: TrendingUp,
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Visão geral do seu negócio
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((card) => (
          <Card key={card.title} className="stat-card animate-slide-up">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {card.title}
                  </p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-24 mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-foreground mt-2">
                      {card.value}
                    </p>
                  )}
                </div>
                <div className={`w-12 h-12 rounded-lg ${card.bgColor} flex items-center justify-center`}>
                  <card.icon className={`w-6 h-6 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-primary" />
            Agendamentos de hoje
          </CardTitle>
        </CardHeader>
        <CardContent>
          {appointmentsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : todayAppointments.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarCheck className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum agendamento para hoje</p>
            </div>
          ) : (
            <div className="space-y-3">
              {todayAppointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <p className="text-lg font-semibold text-primary">
                        {format(new Date(appointment.scheduled_at), 'HH:mm')}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {appointment.duration_minutes}min
                      </p>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {appointment.clients.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {appointment.services.name}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`appointment-pill status-${appointment.status}`}>
                      {appointment.status === 'scheduled' && 'Agendado'}
                      {appointment.status === 'confirmed' && 'Confirmado'}
                      {appointment.status === 'completed' && 'Concluído'}
                      {appointment.status === 'cancelled' && 'Cancelado'}
                      {appointment.status === 'no_show' && 'Falta'}
                    </span>
                    <p className="text-sm font-medium text-foreground mt-1">
                      {formatCurrency(Number(appointment.price))}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
