import { useState, useMemo } from 'react';
import { useAppointments, CreateAppointmentData } from '@/hooks/useAppointments';
import { useClients } from '@/hooks/useClients';
import { useServices } from '@/hooks/useServices';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ChevronLeft, ChevronRight, Plus, MessageCircle } from 'lucide-react';
import {
  format,
  startOfWeek,
  endOfWeek,
  addWeeks,
  subWeeks,
  eachDayOfInterval,
  isSameDay,
  parseISO,
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

export default function Agenda() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('09:00');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [notes, setNotes] = useState('');
  const { toast } = useToast();

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });

  const { appointments, isLoading, createAppointment, updateAppointment } = useAppointments(
    weekStart,
    weekEnd
  );
  const { clients } = useClients();
  const { services } = useServices();

  const days = useMemo(() => {
    return eachDayOfInterval({ start: weekStart, end: weekEnd });
  }, [weekStart, weekEnd]);

  const hours = useMemo(() => {
    const hoursList = [];
    for (let i = 7; i <= 21; i++) {
      hoursList.push(`${i.toString().padStart(2, '0')}:00`);
    }
    return hoursList;
  }, []);

  const selectedService = services.find((s) => s.id === selectedServiceId);

  const handlePrevWeek = () => setCurrentWeek(subWeeks(currentWeek, 1));
  const handleNextWeek = () => setCurrentWeek(addWeeks(currentWeek, 1));
  const handleToday = () => setCurrentWeek(new Date());

  const handleDayClick = (day: Date) => {
    setSelectedDate(day);
    setIsDialogOpen(true);
  };

  const handleCreateAppointment = async () => {
    if (!selectedDate || !selectedClientId || !selectedServiceId || !selectedService) {
      toast({ variant: 'destructive', title: 'Preencha todos os campos obrigatórios' });
      return;
    }

    const [hours, minutes] = selectedTime.split(':').map(Number);
    const scheduledAt = new Date(selectedDate);
    scheduledAt.setHours(hours, minutes, 0, 0);

    const data: CreateAppointmentData = {
      client_id: selectedClientId,
      service_id: selectedServiceId,
      scheduled_at: scheduledAt.toISOString(),
      duration_minutes: selectedService.duration_minutes,
      price: selectedService.price,
      notes: notes || undefined,
    };

    await createAppointment.mutateAsync(data);
    
    // Simulate WhatsApp notification
    const client = clients.find(c => c.id === selectedClientId);
    if (client) {
      toast({
        title: '📱 WhatsApp enviado!',
        description: `Confirmação de agendamento enviada para ${client.name}`,
      });
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setSelectedDate(null);
    setSelectedTime('09:00');
    setSelectedClientId('');
    setSelectedServiceId('');
    setNotes('');
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    await updateAppointment.mutateAsync({ id: appointmentId, status: newStatus as any });
  };

  const getAppointmentsForDay = (day: Date) => {
    return appointments.filter((apt) =>
      isSameDay(parseISO(apt.scheduled_at), day)
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Agenda</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie seus agendamentos
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-gradient-primary">
              <Plus className="w-4 h-4 mr-2" />
              Novo agendamento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Novo Agendamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Data</Label>
                <Input
                  type="date"
                  value={selectedDate ? format(selectedDate, 'yyyy-MM-dd') : ''}
                  onChange={(e) => setSelectedDate(e.target.value ? new Date(e.target.value) : null)}
                />
              </div>
              <div className="space-y-2">
                <Label>Horário</Label>
                <Select value={selectedTime} onValueChange={setSelectedTime}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {hours.map((hour) => (
                      <SelectItem key={hour} value={hour}>
                        {hour}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Cliente</Label>
                <Select value={selectedClientId} onValueChange={setSelectedClientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Serviço</Label>
                <Select value={selectedServiceId} onValueChange={setSelectedServiceId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um serviço" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.filter(s => s.is_active).map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        {service.name} - R$ {Number(service.price).toFixed(2)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {selectedService && (
                <div className="p-3 rounded-lg bg-secondary/50 text-sm">
                  <p className="text-muted-foreground">Duração: {selectedService.duration_minutes} minutos</p>
                  <p className="text-muted-foreground">Valor: R$ {Number(selectedService.price).toFixed(2)}</p>
                </div>
              )}
              <div className="space-y-2">
                <Label>Observações (opcional)</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notas sobre o agendamento..."
                />
              </div>
              <Button
                onClick={handleCreateAppointment}
                className="w-full btn-gradient-primary"
                disabled={createAppointment.isPending}
              >
                Criar agendamento
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-md">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={handlePrevWeek}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" onClick={handleToday}>
                Hoje
              </Button>
              <Button variant="outline" size="icon" onClick={handleNextWeek}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
            <CardTitle className="text-lg">
              {format(weekStart, "d 'de' MMMM", { locale: ptBR })} -{' '}
              {format(weekEnd, "d 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {days.map((day) => {
              const dayAppointments = getAppointmentsForDay(day);
              const isToday = isSameDay(day, new Date());

              return (
                <div key={day.toISOString()} className="min-h-[160px]">
                  <div
                    className={cn(
                      'text-center p-2 rounded-t-lg font-medium text-sm',
                      isToday ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground'
                    )}
                  >
                    <p>{format(day, 'EEE', { locale: ptBR })}</p>
                    <p className="text-lg">{format(day, 'd')}</p>
                  </div>
                  <div
                    className="calendar-day rounded-t-none cursor-pointer hover:bg-secondary/80"
                    onClick={() => handleDayClick(day)}
                  >
                    <div className="space-y-1 overflow-y-auto max-h-28">
                      {dayAppointments.slice(0, 3).map((apt) => (
                        <div
                          key={apt.id}
                          className={cn('appointment-pill', `status-${apt.status}`)}
                          onClick={(e) => e.stopPropagation()}
                        >
                          <span className="font-medium">
                            {format(parseISO(apt.scheduled_at), 'HH:mm')}
                          </span>{' '}
                          {apt.clients.name.split(' ')[0]}
                        </div>
                      ))}
                      {dayAppointments.length > 3 && (
                        <p className="text-xs text-muted-foreground text-center">
                          +{dayAppointments.length - 3} mais
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Daily detail view */}
          <div className="mt-6 space-y-3">
            <h3 className="font-semibold text-foreground">Próximos agendamentos</h3>
            {appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length === 0 ? (
              <p className="text-muted-foreground text-sm">Nenhum agendamento pendente nesta semana</p>
            ) : (
              appointments
                .filter(a => ['scheduled', 'confirmed'].includes(a.status))
                .slice(0, 5)
                .map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-secondary/50"
                  >
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="font-medium">{apt.clients.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {apt.services.name} •{' '}
                          {format(parseISO(apt.scheduled_at), "EEE, d 'de' MMM 'às' HH:mm", {
                            locale: ptBR,
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={apt.status}
                        onValueChange={(value) => handleStatusChange(apt.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="scheduled">Agendado</SelectItem>
                          <SelectItem value="confirmed">Confirmado</SelectItem>
                          <SelectItem value="completed">Concluído</SelectItem>
                          <SelectItem value="cancelled">Cancelado</SelectItem>
                          <SelectItem value="no_show">Falta</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          toast({
                            title: '📱 WhatsApp',
                            description: `Lembrete enviado para ${apt.clients.name}`,
                          });
                        }}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
